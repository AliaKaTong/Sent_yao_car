import sensor, image, time, math ,lcd
import ustruct
from pyb import UART
import json
GRAYSCALE_THRESHOLD = [(10, 74, 11, 120, -20, 80)]
ROIS = [
 (0, 100, 160, 20, 0.7),
 (0, 50, 160, 20, 0.3),
 (0, 0, 160, 20, 0.1)
 ]

# 十字路口的roi（可根据小车需要停止的距离调节）
ROI_SI = [
  (0, 44, 20, 60),    #18
  (140, 44, 20, 60)
 ]

weight_sum = 0
for r in ROIS: weight_sum += r[4]
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)
sensor.set_vflip(1)
sensor.set_hmirror(1)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
sensor.skip_frames(time = 2000)
uart = UART(3, 115200)
clock = time.clock()
cross = 1
while(True):
     clock.tick()
     img = sensor.snapshot()
     centroid_sum = 0
     weight_sum = 0
     for r in ROIS:
         blobs = img.find_blobs(GRAYSCALE_THRESHOLD, roi=r[0:4], merge=True)
         if blobs:
             largest_blob = max(blobs, key=lambda b: b.pixels())
             #img.draw_rectangle(largest_blob.rect())
             #img.draw_cross(largest_blob.cx(),largest_blob.cy())
             centroid_sum += largest_blob.cx() * r[4]
             weight_sum += r[4]
     if weight_sum != 0:
        center_pos = (centroid_sum / weight_sum)
        deflection_angle = 0
        deflection_angle = -math.atan((center_pos-80)/60)
        deflection_angle = math.degrees(deflection_angle)+10
        #img.draw_string(0, 0, str(deflection_angle), color = (255, 255,
                     #255), scale = 2,mono_space = False)
     else:
        deflection_angle = 0
        #img.draw_string(0, 0, str(deflection_angle), color = (255, 255,
                     #255), scale = 2,mono_space = False)

     for r in ROI_SI:
        blobs = img.find_blobs(GRAYSCALE_THRESHOLD, roi=r[0:4], merge=True)
        if blobs:
            largest_blob = max(blobs, key=lambda b: b.pixels())
            #img.draw_rectangle(largest_blob.rect())
            #img.draw_cross(largest_blob.cx(),largest_blob.cy())
            cross = 2
     print(cross)
     output_str = "%d" % (deflection_angle)
     FH = bytearray([0xac,int(output_str),int(cross)])
     uart.write(FH)
     cross = 1
