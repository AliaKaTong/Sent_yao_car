# Copyright (c) 2016 STMicroelectronics

This software component is licensed by STMicroelectronics under the **BSD-3-Clause** license. You may not use this file except in compliance with this license. You may obtain a copy of the license [here](https://opensource.org/licenses/BSD-3-Clause).