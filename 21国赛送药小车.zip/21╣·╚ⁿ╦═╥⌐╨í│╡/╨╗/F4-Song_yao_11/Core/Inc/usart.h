/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the usart.c file
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;

/* USER CODE BEGIN Private defines */
#define  UART_ENABLE_RE(USARTx)       USARTx.Instance->CR1|= (uint32_t)0x0004            
#define  UART_DISABLE_RE(USARTx)      USARTx.Instance->CR1&= (~(uint32_t)0x0004)   
#define close_uart1 UART_DISABLE_RE(huart1)
#define close_uart2 UART_DISABLE_RE(huart2);
#define open_uart1 UART_ENABLE_RE(huart1)
#define open_uart2 UART_ENABLE_RE(huart2);

#define close_exit0 HAL_NVIC_DisableIRQ(EXTI0_IRQn);
#define close_exit4 HAL_NVIC_DisableIRQ(EXTI4_IRQn);
#define close_exit5 HAL_NVIC_DisableIRQ(EXTI9_5_IRQn);
#define open_exit0 HAL_NVIC_EnableIRQ(EXTI0_IRQn);
#define open_exit4 HAL_NVIC_EnableIRQ(EXTI4_IRQn);
#define open_exit5 HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);



/* USER CODE END Private defines */

void MX_USART1_UART_Init(void);
void MX_USART2_UART_Init(void);

/* USER CODE BEGIN Prototypes */

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
