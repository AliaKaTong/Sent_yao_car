import sensor,image,lcd,time
import KPU as kpu
from machine import UART
from fpioa_manager import fm
import json
lcd.init(freq=15000000)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)

sensor.set_vflip(1)
sensor.set_hmirror(1)

sensor.run(1)
task = kpu.load("/sd/yolov5.kmodel")
f=open("anchors.txt","r")
anchor_txt=f.read()
L=[]
for i in anchor_txt.split(","):
    L.append(float(i))
anchor=tuple(L)
f.close()
f=open("lable.txt","r")
lable_txt=f.read()
lable = lable_txt.split(",")
f.close()
fm.register(14, fm.fpioa.UART1_TX, force=True)
# fm.register(15, fm.fpioa.UART1_RX, force=True)
uart_A = UART(UART.UART1, 115200, 8, 1, 0, timeout=1000, read_buf_len=4096)
anchor = (0.1766, 0.1793, 0.4409, 0.3797, 0.6773, 0.5954, 1.0218, 0.9527, 2.158, 1.6841)
sensor.set_windowing((224, 224))
a = kpu.init_yolo2(task, 0.5, 0.3, 5, anchor)
classes=["9","1","4","2","3","8","5","6","7" ]
last_num = 0;
while(True):
     img = sensor.snapshot()
     code = kpu.run_yolo2(task, img)
     if code:
         for i in code:
             a=img.draw_rectangle(i.rect())
             a = lcd.display(img)
             list1=list(i.rect())
             b=(list1[0]+list1[2])/2
             #c=(list1[1]+list1[3])/2
             #print("物体是：",classes[i.classid()])
             #print("概率为：",100.00*i.value())
             #print("坐标为：",b)
             lcd.draw_string(i.x(), i.y(), classes[i.classid()], lcd.RED, lcd.WHITE)
             #uart_A.write(classes[i.classid()])
             #uart_A.write(str(b))
             num = classes[i.classid()]
             uart_A.write( bytearray([0xab,int(num),int(b)]) )
             #if(num != last_num):  #用来判断数字是否有改变，改变了就发送出去
                #last_num = num
                #FH = bytearray([0xab,int(num),int(b)])
                #uart_A.write(FH)
             #for i in code:
                 # lcd.draw_string(i.x(), i.y(), classes[i.classid()], lcd.RED, lcd.WHITE)
                 # lcd.draw_string(i.x(), i.y()+12, '%f'%i.value(), lcd.RED, lcd.WHITE)
                 # lcd.draw_string(50, 200,str(b), lcd.RED, lcd.WHITE)
                 # lcd.draw_string(110, 200,str(c), lcd.RED, lcd.WHITE)
                 # uart_A.write(classes[i.classid()]+'\r\n')
                 # uart_A.write(str(b)+'\r\n')
                 # uart_A.write(str(c)+'\r\n')
     else:
         a = lcd.display(img)



uart_A.deinit()
del uart_A
a = kpu.deinit(task)
